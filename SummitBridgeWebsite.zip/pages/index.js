
import React from "react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col justify-between font-inter">
      <header className="flex justify-between items-center px-8 py-6 bg-black/70 backdrop-blur-sm fixed w-full z-50">
        <div className="flex items-center gap-2">
          <span className="text-yellow-500 text-2xl font-serif">⛰️</span>
          <h1 className="text-xl font-semibold">Summit Bridge Partners</h1>
        </div>
        <nav className="space-x-6">
          <a href="#about" className="text-gray-300 hover:text-white">About</a>
          <a href="#services" className="text-gray-300 hover:text-white">Services</a>
          <a href="#contact" className="text-yellow-500 font-semibold">Let's Talk</a>
        </nav>
      </header>

      <div className="relative h-screen flex items-center justify-center">
        <img
          src="/clouds-bw-background.jpg"
          alt="Clouds Background"
          className="absolute w-full h-full object-cover opacity-30"
        />
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-4xl md:text-6xl font-serif text-center px-4 text-white"
        >
          Dedicated to the hard work of realizing big dreams
        </motion.h1>
      </div>

      <section id="about" className="max-w-6xl mx-auto px-4 py-12 grid md:grid-cols-2 gap-8">
        <Card className="bg-gray-900 text-white shadow-lg rounded-2xl">
          <CardContent className="p-6">
            <h2 className="text-2xl font-serif font-bold mb-4">Who We Are</h2>
            <p>
              We are a boutique placement agent committed to helping private equity firms connect with the right investors. Our team pairs deep relationships with an empathetic, human approach. We work tirelessly to bridge ambition and opportunity.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 text-white shadow-lg rounded-2xl">
          <CardContent className="p-6">
            <h2 className="text-2xl font-serif font-bold mb-4">How We Can Help</h2>
            <p>
              Our expertise lies in raising capital for private equity, venture capital, and real asset funds. We bring heart, hustle, and expertise to every engagement, focusing on authentic, long-term partnerships over transactions.
            </p>
          </CardContent>
        </Card>
      </section>

      <section id="contact" className="text-center py-12 bg-gray-950">
        <h3 className="text-2xl font-serif mb-4">Start the Conversation</h3>
        <Button className="bg-yellow-500 text-black font-semibold px-6 py-3 rounded-2xl shadow-md hover:bg-yellow-400 transition">
          Let's Talk
        </Button>
      </section>

      <footer className="bg-gray-950 text-gray-400 py-6 text-center text-sm">
        <p>© 2025 Summit Bridge Partners. Built on relationships, driven by results.</p>
      </footer>
    </div>
  );
}
